module.exports = (req , res , next) => {
		
		// Fill in the code
		// render handlebars view
		res.render('addEmployeeView')
};
